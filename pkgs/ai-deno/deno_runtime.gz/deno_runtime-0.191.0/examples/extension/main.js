// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.
console.log("Hello world from JS!");
console.log(Deno.build);
Extension.hello();
